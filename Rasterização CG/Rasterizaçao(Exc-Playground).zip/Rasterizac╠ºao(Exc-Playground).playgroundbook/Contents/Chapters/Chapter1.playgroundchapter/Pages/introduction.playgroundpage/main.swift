//: # Rasterização de Retas e Polígonos
//: ### Dupla: Ana Karolina e Paulo Rubem
/*:
 
 O trabalho apresentado a seguir foi desenvolvido baseando-se no nos algoritmos apresentados nas subseções 5.2.1 e 5.2.2 do livro Computação Gráfica Teoria e Prática - Eduardo Azevedo, os quais foram apresentados na aula do dia 10/09/2021. Tendo como critérios de implementação:
 
 - Obter 3 imagens da rasterização de 4 semiretas diferente para 3 resoluções diferentes e comparar as retas. Levando em conta uma implementação com as retas em posições distintas, onde uma estara na Horizontal e outra na Vertical. Também datende os casos onde delaX > deltaY e deltaY > detalX.
 
-  Obter 6 imagens de rasterização de poligonos, para triangulo equilátero, quadrado e hexagono, sendo duas imagens para cada e cada imagem em 3 resoluções.
 */
//#-hidden-code
import SwiftUI
import PlaygroundSupport
struct ContentView: View {
    
    var body: some View {
        ZStack{
            Text("Essa página não tem nenhuma desmonstração.")
                .foregroundColor(.black)
                .font(.title)
                .fontWeight(.bold)
                .frame(maxWidth: .greatestFiniteMagnitude, alignment: .center)
            
            
        }.frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.width)
    }
}

PlaygroundPage.current.setLiveView(ContentView().background(Color.white))
//#-end-hidden-code




