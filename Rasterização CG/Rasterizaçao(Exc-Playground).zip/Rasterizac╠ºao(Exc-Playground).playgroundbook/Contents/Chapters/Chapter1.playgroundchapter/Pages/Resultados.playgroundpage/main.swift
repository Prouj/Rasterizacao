//: # Resultados
//: .
/*:

 Como pode ser visto na página anterior a uma grande diferença na nossa percepção de um objeto dependendo de sua resolução, podendo o mesmo ficar com pixels mais evidentes ao se dimuniuir a resolução, ou mais suaves ao se aumentar a resolução.
 Sendo assim, é inegável que as mudanças na resolução causam o efeitos nos objetos, e caso fosse aumentado ainda mais a resolução das imagens seria cada vez mais próximo de um objeto sem pixels tão aparentes.
 
 Acerca das retas geradas podemos ver a relação de seus pontos com a construção dos deltas e a forma como as mesmas se deslocaram pelo gráfico.

 - Reta 1:
     - Ponto Inicial =  (0, 40)
     - Ponto Final = (40, 40)
     - Com esses pontos, é possível perceber que devido a posição Y inicial ser igual a posição Y final, a reta possui deslocamento horizontal.

 - Reta 2:
    - Ponto Inicial = (25,0)
    - Ponto Final = (25, 25)
    - Com esses pontos, é possível perceber que devido a posição Y inicial ser igual a posição Y final, a reta possui deslocamento horizontal.

  - Reta 3:
    - Ponto Inicial = (0,15)
    - Ponto Final = (11, 29)
    - Com esses pontos, é possível perceber que o deltaY essa reta é maior que o deltaX, ou seja a reta possui um crescimento maior na vertical.

 - Reta 4:
    - Ponto Inicial = (40,15)
    - Ponto Final = (30, 30)
    - Com esses pontos, é possível perceber que o deltaY essa reta é maior que o deltaX, ou seja a reta possui um crescimento maior na vertical.

 */

//#-hidden-code
import SwiftUI
import PlaygroundSupport
struct ContentView: View {
    
    var body: some View {
        ZStack{
            Text("Essa página não tem nenhuma desmonstração.")
                .foregroundColor(.black)
                .font(.title)
                .fontWeight(.bold)
                .frame(maxWidth: .greatestFiniteMagnitude, alignment: .center)
            
            
        }.frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.width)
    }
}

PlaygroundPage.current.setLiveView(ContentView().background(Color.white))
//#-end-hidden-code
